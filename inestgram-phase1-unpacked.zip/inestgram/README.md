# iNESTGRAM web — Phase 1 (demo UI)
Frontend only: no backend, auth, uploads or media permissions yet (Phases 2–3).

    npm install
    npm run dev        # serves on 0.0.0.0:3000
    npm run typecheck

Preview on iPhone: same Wi-Fi as your computer → open http://<computer-LAN-IP>:3000 in Safari.
Or deploy to Vercel (HTTPS) and open the URL; Share → Add to Home Screen.
Demo media: picsum.photos images and Google sample-bucket videos. Verify licenses before production.
