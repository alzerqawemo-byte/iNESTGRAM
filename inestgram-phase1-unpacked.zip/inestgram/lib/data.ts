// Demo data only: fictional users. Images: picsum.photos (Unsplash-sourced, free to use).
// Videos: Google sample bucket (Blender / Google demo clips). Verify licenses before production.
export type User = { id: string; name: string; bio: string; followers: number; following: number };
export type Post = { id: string; user: string; img: string; caption: string; likes: number; comments: number; place?: string };
export type Reel = { id: string; user: string; src: string; poster: string; caption: string; likes: number };

const V = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/";
export const avatar = (id: string) => `https://picsum.photos/seed/av-${id}/160/160`;
export const photo = (s: string, w = 800, h = 800) => `https://picsum.photos/seed/${s}/${w}/${h}`;

export const users: User[] = [
  { id: "lina.wanders", name: "Lina Haddad", bio: "Slow travel · film cameras · tea", followers: 12400, following: 310 },
  { id: "omar.frames", name: "Omar Tariq", bio: "Street photographer, Baghdad → Berlin", followers: 8920, following: 205 },
  { id: "nour.cooks", name: "Nour Aziz", bio: "Home cook. Big pots, small kitchen.", followers: 20310, following: 150 },
  { id: "kai.skate", name: "Kai Mori", bio: "Skating at golden hour", followers: 5400, following: 480 },
  { id: "sara.studio", name: "Sara Nabil", bio: "Ceramics + plants", followers: 15800, following: 96 },
  { id: "yusuf.trails", name: "Yusuf Amin", bio: "Hiking every weekend", followers: 3120, following: 220 },
  { id: "maya.pixels", name: "Maya Ortiz", bio: "Digital artist & cat person", followers: 27050, following: 60 },
  { id: "zaid.beats", name: "Zaid Karim", bio: "Beats, vinyl, late nights", followers: 9100, following: 301 },
];
export const me: User = { id: "you.demo", name: "Demo Visitor", bio: "Welcome to iNESTGRAM. This is a demo profile.", followers: 128, following: 64 };

const caps = ["Golden hour never gets old.", "Found this corner by accident.", "Sunday slow down.", "New week, new light.", "Quiet streets, loud colors.", "Notes from the road.", "Made this today.", "Still thinking about this view."];
const places = ["Lisbon", "Istanbul", "Kyoto", "Amman", "Oslo", "Marrakesh", "Lima", "Hanoi"];
export const posts: Post[] = Array.from({ length: 16 }, (_, i) => ({
  id: `p${i}`, user: users[i % users.length].id, img: photo(`inest${i}`, 800, i % 3 === 0 ? 1000 : 800),
  caption: caps[i % caps.length], likes: 120 + ((i * 937) % 4800), comments: 3 + ((i * 17) % 90), place: places[i % places.length],
}));

export const reels: Reel[] = [
  { id: "r1", user: "kai.skate", src: V + "ForBiggerBlazes.mp4", poster: photo("rp1", 540, 960), caption: "Fire and speed", likes: 5230 },
  { id: "r2", user: "yusuf.trails", src: V + "ForBiggerEscapes.mp4", poster: photo("rp2", 540, 960), caption: "Escape the weekend", likes: 3110 },
  { id: "r3", user: "maya.pixels", src: V + "ForBiggerJoyrides.mp4", poster: photo("rp3", 540, 960), caption: "Joyride mode", likes: 9020 },
  { id: "r4", user: "zaid.beats", src: V + "BigBuckBunny.mp4", poster: photo("rp4", 540, 960), caption: "Cartoon break (Blender, CC-BY)", likes: 15000 },
];
export const byId = (id: string) => users.find((u) => u.id === id) ?? me;
