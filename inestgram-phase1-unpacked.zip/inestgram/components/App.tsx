"use client";
import { useEffect, useRef, useState } from "react";
import { avatar, byId, me, posts, photo, reels, users, type Post } from "@/lib/data";

type Tab = "home" | "explore" | "reels" | "search" | "profile";
const P: Record<string, string> = {
  home: "M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z",
  explore: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  reels: "M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM3 9h18M10 12.5v4l4-2z",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-4-4",
  profile: "M12 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM4 21c0-4 4-6 8-6s8 2 8 6",
  heart: "M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z",
  comment: "M21 12a8 8 0 0 1-11.5 7.2L4 20l1-4.6A8 8 0 1 1 21 12z",
  send: "M22 3L11 14M22 3l-7 18-4-7-7-4z",
  save: "M6 3h12v18l-6-4-6 4z",
  moon: "M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10z",
  sun: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5",
  back: "M15 5l-7 7 7 7",
};
const Icon = ({ n, on }: { n: string; on?: boolean }) => (
  <svg className={`ico${on ? " on" : ""}`} viewBox="0 0 24 24" aria-hidden="true"><path d={P[n]} /></svg>
);
const fmt = (n: number) => (n >= 1e6 ? (n / 1e6).toFixed(1) + "M" : n >= 1e3 ? (n / 1e3).toFixed(1) + "K" : String(n));

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  const [dark, setDark] = useState(false);
  const [profileId, setProfileId] = useState<string>(me.id);
  const [open, setOpen] = useState<Post | null>(null);
  const [liked, setLiked] = useState<Record<string, boolean>>({});
  const [seen, setSeen] = useState<Record<string, boolean>>({});

  useEffect(() => {
    let s: string | null = null;
    try { s = localStorage.getItem("inest-theme"); } catch {}
    setDark(s ? s === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches);
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    try { localStorage.setItem("inest-theme", dark ? "dark" : "light"); } catch {}
  }, [dark]);

  const toggleLike = (id: string) => setLiked((l) => ({ ...l, [id]: !l[id] }));
  const goProfile = (id: string) => { setProfileId(id); setTab("profile"); };
  const nav: Tab[] = ["home", "explore", "reels", "search", "profile"];

  return (
    <div className="app">
      <header className="top">
        <div className="logo">
          <svg viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="g" x1="0" x2="1"><stop stopColor="#5b5bf0" /><stop offset="1" stopColor="#ff4d79" /></linearGradient></defs>
            <path d="M4 18c0-6 5-11 12-11s12 5 12 11" fill="none" stroke="url(#g)" strokeWidth="3" strokeLinecap="round" /><path d="M7 20c3 5 15 5 18 0" fill="none" stroke="url(#g)" strokeWidth="3" strokeLinecap="round" /><circle cx="16" cy="15" r="3.2" fill="url(#g)" /></svg>
          <span>i<b>NEST</b>GRAM</span>
        </div>
        <button aria-label={dark ? "Switch to light theme" : "Switch to dark theme"} onClick={() => setDark(!dark)}><Icon n={dark ? "sun" : "moon"} /></button>
      </header>

      <main className={`main${tab === "reels" ? " reels" : ""}`}>
        {tab === "home" && (<>
          <div className="stories" role="list">
            {[me, ...users].map((u) => (
              <button key={u.id} className="story" role="listitem" onClick={() => setSeen((s) => ({ ...s, [u.id]: true }))}>
                <div className={`ring${seen[u.id] ? " seen" : ""}`}><img src={avatar(u.id)} alt="" /></div>
                <span>{u.id === me.id ? "Your story" : u.id.split(".")[0]}</span>
              </button>
            ))}
          </div>
          {posts.slice(0, 8).map((p) => <PostCard key={p.id} p={p} liked={!!liked[p.id]} onLike={() => toggleLike(p.id)} onUser={goProfile} />)}
          <p className="demo">Demo content · fictional users · photos from picsum.photos</p>
        </>)}
        {tab === "explore" && (
          <div className="grid">
            {posts.map((p, i) => (
              <button key={p.id} className={i % 7 === 0 ? "tall" : ""} onClick={() => setOpen(p)} aria-label={`Post by ${p.user}`}>
                <img src={p.img.replace(/\/\d+\/\d+$/, "/400/" + (i % 7 === 0 ? 800 : 400))} alt={p.caption} loading="lazy" />
              </button>
            ))}
          </div>
        )}
        {tab === "reels" && <Reels liked={liked} onLike={toggleLike} onUser={goProfile} />}
        {tab === "search" && <Search onUser={goProfile} />}
        {tab === "profile" && <Profile id={profileId} onBack={profileId !== me.id ? () => setProfileId(me.id) : undefined} onOpen={setOpen} />}
      </main>

      {open && (
        <div className="modal" onClick={() => setOpen(null)} role="dialog" aria-label="Post preview">
          <div className="box" onClick={(e) => e.stopPropagation()}>
            <img src={open.img} alt={open.caption} />
            <div><b>{open.user}</b> {open.caption}<p className="demo" style={{ padding: 0, textAlign: "left" }}>{fmt(open.likes)} likes · {open.comments} comments</p></div>
          </div>
        </div>
      )}

      <nav className="nav" aria-label="Main">
        {nav.map((t) => (
          <button key={t} aria-label={t} aria-current={tab === t ? "page" : undefined} onClick={() => { setTab(t); if (t === "profile") setProfileId(me.id); }}><Icon n={t} on={tab === t && t !== "search"} /></button>
        ))}
      </nav>
    </div>
  );
}

function PostCard({ p, liked, onLike, onUser }: { p: Post; liked: boolean; onLike: () => void; onUser: (id: string) => void }) {
  const [saved, setSaved] = useState(false);
  return (
    <article className="post">
      <div className="ph">
        <img src={avatar(p.user)} alt="" />
        <div><button className="n" onClick={() => onUser(p.user)}>{p.user}</button><div className="p">{p.place}</div></div>
      </div>
      <img src={p.img} alt={p.caption} loading="lazy" onDoubleClick={() => !liked && onLike()} />
      <div className="acts">
        <button className={`heart${liked ? " on pop" : ""}`} aria-label="Like" aria-pressed={liked} onClick={onLike}><Icon n="heart" on={liked} /></button>
        <button aria-label="Comment"><Icon n="comment" /></button>
        <button aria-label="Share"><Icon n="send" /></button>
        <span className="sp" />
        <button aria-label="Save" aria-pressed={saved} onClick={() => setSaved(!saved)}><Icon n="save" on={saved} /></button>
      </div>
      <div className="meta"><b>{fmt(p.likes + (liked ? 1 : 0))} likes</b><div><b>{p.user}</b> {p.caption}</div><div className="c">View all {p.comments} comments</div></div>
    </article>
  );
}

function Reels({ liked, onLike, onUser }: { liked: Record<string, boolean>; onLike: (id: string) => void; onUser: (id: string) => void }) {
  const [muted, setMuted] = useState(true);
  const refs = useRef<(HTMLVideoElement | null)[]>([]);
  useEffect(() => {
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      const v = e.target as HTMLVideoElement;
      if (e.isIntersecting) v.play().catch(() => {}); else v.pause();
    }), { threshold: 0.6 });
    refs.current.forEach((v) => v && io.observe(v));
    return () => io.disconnect();
  }, []);
  return (
    <div className="rl">
      {reels.map((r, i) => (
        <section className="reel" key={r.id}>
          <video ref={(el) => { refs.current[i] = el; }} src={r.src} poster={r.poster} muted={muted} loop playsInline preload="metadata" onClick={(e) => { const v = e.currentTarget; if (v.paused) v.play(); else v.pause(); }} />
          <span className="badge">Reels · demo</span>
          <div className="ov">
            <div><button style={{ fontWeight: 700 }} onClick={() => onUser(r.user)}>@{r.user}</button><p style={{ fontSize: 14, marginTop: 4 }}>{r.caption}</p></div>
            <div className="side">
              <button className={`heart${liked[r.id] ? " on pop" : ""}`} aria-label="Like" onClick={() => onLike(r.id)}><Icon n="heart" on={!!liked[r.id]} /></button>
              <span>{fmt(r.likes + (liked[r.id] ? 1 : 0))}</span>
              <button aria-label={muted ? "Unmute" : "Mute"} onClick={() => setMuted(!muted)} style={{ fontSize: 12 }}>{muted ? "Sound off" : "Sound on"}</button>
            </div>
          </div>
        </section>
      ))}
    </div>
  );
}

function Search({ onUser }: { onUser: (id: string) => void }) {
  const [q, setQ] = useState("");
  const list = users.filter((u) => (u.id + u.name).toLowerCase().includes(q.trim().toLowerCase()));
  return (
    <>
      <div className="search"><input type="search" placeholder="Search people" aria-label="Search people" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      {list.map((u) => (
        <button className="row" key={u.id} onClick={() => onUser(u.id)}>
          <img src={avatar(u.id)} alt="" /><div><b>{u.id}</b><div className="s">{u.name} · {fmt(u.followers)} followers</div></div>
        </button>
      ))}
      {!list.length && <p className="empty">No one matches “{q}”. Try a different name.</p>}
    </>
  );
}

function Profile({ id, onBack, onOpen }: { id: string; onBack?: () => void; onOpen: (p: Post) => void }) {
  const u = byId(id);
  const [following, setFollowing] = useState(false);
  const mine = id === me.id ? posts.slice(0, 6) : posts.filter((p) => p.user === id);
  const list = mine.length ? mine : posts.slice(0, 3).map((p) => ({ ...p, user: id, img: photo(`${id}-${p.id}`) }));
  return (
    <>
      <div className="prof">
        {onBack && <button aria-label="Back" onClick={onBack}><Icon n="back" /></button>}
        <div className="h">
          <img src={avatar(u.id)} alt="" />
          <div className="stats"><div><b>{list.length}</b>posts</div><div><b>{fmt(u.followers + (following ? 1 : 0))}</b>followers</div><div><b>{fmt(u.following)}</b>following</div></div>
        </div>
        <h2>{u.name}</h2><p>@{u.id}</p><p>{u.bio}</p>
        <div className="btns">
          {id === me.id ? <button className="btn ghost">Edit profile</button> : <button className={`btn${following ? " ghost" : ""}`} onClick={() => setFollowing(!following)}>{following ? "Following" : "Follow"}</button>}
          <button className="btn ghost">Message</button>
        </div>
      </div>
      <div className="grid">{list.map((p) => <button key={p.id} onClick={() => onOpen(p)} aria-label="Open post"><img src={p.img.replace(/\/\d+\/\d+$/, "/400/400")} alt={p.caption} loading="lazy" /></button>)}</div>
    </>
  );
}
